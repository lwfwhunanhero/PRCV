library(MASS)
library(glasso)
library(glmnet)
source("functions_permutation.R")
PBA<-function(X,p,n,M,sigma){
  U <- 3*diag(p)
  alpha.c <- 3
  alpha.b <- 2
  iter <- 1
  lambdas <- c(1,2*qnorm(p=(0.1/(2*p*(1:(p-1)))),lower.tail=FALSE))/sqrt(n)
    S <- 1/n*t(X)%*%X
    
    models <- list(Matrix=list(),Lmle=list(),Dmle=list(),Lmap=list(),Dmap=list(),Lexpect=list(),
                   Dexpect=list(), Tlasso = list(), Dlasso = list())
    
    cv.lasso <- function(x, y) {
      lambdas <- seq(0.3, 0.01, -0.01)
      errors <- rep(0, length(lambdas))
      f <- split(1:length(y), sample(1:10, length(y), replace=T))
      for (i in 1:length(lambdas)) {
        error <- 0
        for (g in 1:length(f)) {
          xg <- x[-f[[g]]]
          yg <- y[-f[[g]]]
          cvFunc <- function(t) {
            return(sum((yg-xg*t)^2)/(2*length(yg))+lambdas[i]*abs(t))
          }
          cv.res <- optim(0, cvFunc, method='BFGS')
          xt <- x[f[[g]]]
          yt <- y[f[[g]]]
          error <- error+sum((yt-xt*cv.res$par)^2)
        }
        errors[i] <- error
      }
      lambda.min <- lambdas[which.min(errors)]
      func <- function(t) {
        return(sum((y-x*t)^2)/(2*length(y))+lambda.min*abs(t))
      }
      res <- optim(0, func, method='BFGS')
      return(res$par)
    }
    
    for (k in 1:M) {
      funcPi <- sample(p)
      models$Matrix[[k]] <- matrix(0, p, p)
      for (i in 1:p) {
        models$Matrix[[k]][funcPi[i], i] <- 1
      }
      X.perm <- X%*%models$Matrix[[k]]
      models$Tlasso[[k]] <- diag(p)
      models$Dlasso[[k]] <- diag(p) * sqrt(var(X.perm[, 1]))
      for (j in 1:p) {
        if (funcPi[j] == 1) next
        if (funcPi[j] == 2) {
          res <- cv.lasso(X.perm[, 1:(funcPi[j]-1)], X.perm[, funcPi[j]])
          models$Tlasso[[k]][2, 1] <- res
          models$Dlasso[[k]][2, 2] <- sqrt(var(X.perm[, 2] - X.perm[, 1] * res))
        } else {
          cvob <- cv.glmnet(as.matrix(X.perm[, 1:(funcPi[j]-1)]), X.perm[, funcPi[j]], alpha=1)
          fit <- glmnet(X.perm[, 1:(funcPi[j]-1)], X.perm[, funcPi[j]], alpha=1, lambda=cvob$lambda.min)
          models$Tlasso[[k]][funcPi[j], 1:(funcPi[j]-1)] <- as(fit$beta, 'vector')
          models$Dlasso[[k]][funcPi[j], funcPi[j]] <- sqrt(var(X.perm[, funcPi[j]] - X.perm[, 1:(funcPi[j]-1)] %*% as(fit$beta, 'vector')))
        }
      }
      
      S.perm <- 1/n*t(X.perm)%*%X.perm
      ch <- chol(solve(S.perm+0.1*diag(p)))
      dd <- diag(ch) 
      L.epsilon <- t(ch/dd)
      for(i in 2:p){
        for(j in 1:(i-1)){
          if(abs(L.epsilon[i,j]) < 0.2) L.epsilon[i,j] <- 0
          else L.epsilon[i,j] <- 1}}
      diag(L.epsilon) <- 0
      map.precision <- solve(DAG.MAP(S.perm,Adj = L.epsilon,U,alpha.c,alpha.b,n))
      ch <- chol(map.precision)
      dd <- diag(ch) 
      models$Lmap[[k]] <- models$Matrix[[k]]%*%t(ch/dd)%*%t(models$Matrix[[k]])
      models$Dmap[[k]] <- models$Matrix[[k]]%*%diag(dd)%*%t(models$Matrix[[k]])
      if(k %% 100 == 0) cat(k, 'iterations completed.')
    }
    L.final.map <- matrix(0,p,p)
    D.final.map <- matrix(0,p,p)
    for( w in 1:M){
      L.final.map <- L.final.map + models$Lmap[[w]]
      D.final.map <- D.final.map + models$Dmap[[w]]
    }
    L.final.map <- 1/M*L.final.map
    D.final.map <- 1/M*D.final.map
    
    precision.final.map <- L.final.map%*%solve(D.final.map)%*%t(L.final.map)
    
    ######hard thresholding###########
    thres <- seq(0.1,0.5, by = 0.001)
    BIC <- rep(0,length(thres))
    for (u in 1:length(thres)) {
      L.thres <- L.final.map
      for(t in 2:p){
        for (r in 1:(t-1)) {if(abs(L.final.map[t,r]) < thres[u]) L.thres[t,r] <- 0}
      }
      BIC[u] <- n*(sum(diag(S%*%(L.thres)%*%solve(D.final.map)%*%t(L.thres)))) + log(n)*sum(L.thres!=0)
    }
    thres[which.min(BIC)]
    final.delta.L <- L.final.map
    for(c in 2:p){
      for (d in 1:(t-1)) {if(abs(L.final.map[c,d]) < thres[which.min(BIC)]) L.thres[c,d] <- 0}
    }
    final.delta.precision <- final.delta.L%*%D.final.map%*%t(final.delta.L)
  return(final.delta.precision)
}