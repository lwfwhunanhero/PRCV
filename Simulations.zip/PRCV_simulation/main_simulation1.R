## code for Case 1 with normal and t distribution
rm(list = ls())
set.seed(666)
library(foreach)
library(doParallel)
library(SIS)
library(lars)
library(ncvreg)
library(glmnet)
library(MASS)
library(huge)
library(flare)
library(LaplacesDemon) #multi_dim cauchy and t
library(pROC) #AUC_norm
library(msaenet) #SCAD + AIC/BIC
source("rcvma.R")
source("prcvma.R")
source("KLloss.R")
source("varma.R")
source("PBA.R")
source("imcd.R")
##################################   
rs<-rt<-NULL;iters=20; n=200 
##################################   
Loss_res_func <- function(Sigma,Omega,O_est,p){
  res <- c(KL(Sigma,O_est),F_norm(Omega,O_est),
           AUC_norm(Omega,O_est),Entrymax_norm(Omega,O_est),
           norm(Omega-O_est,type = "2")
  )
  return(res)
}
##################################
for(case in c(1,2)){
  for(M in c(30,40,80)){
    for(p in c(100,200,500)){
      ######### case1
      mu<-rep(0,p)
      L<-matrix(0,nrow=p,ncol=p) + diag(p)
      for(i in 1:(p-1)){
        L[i+1,i]<-0.5
      }
      D<-diag(p)
      Omega<-(t(L))%*%(L)
      Sigma<-(solve(L))%*%(solve(t(L)))
      ###############  1  ########################
      if(case==1){
        data<-list()
        for(i in 1:iters){
          X<-mvrnorm(n,mu,Sigma)
          data[[i]]<-X
        }
      }
      ####################     2  t    ##############   
      if(case==2){
        data<-list()
        for(i in 1:iters){
          X <- LaplacesDemon::rmvt(n,mu,Sigma,df=7)
          data[[i]]<-X
        }
      }
      ##################################   
      cores <- detectCores(logical=F)
      cl <- makeCluster(50)
      registerDoParallel(cl,cores=cores)
      clusterEvalQ(cl,library(SIS))
      size<-iters/5
      
      start_time <- proc.time()
      
      result<-foreach(j=1:5, .combine = 'rbind',.packages=c('flare','huge','glmnet',
                                                            'pROC','scio','msaenet')) %dopar%
        {
          length_loss <- 5
          length_method <- 6
          res<-matrix(0,nrow=size,ncol=length_loss*length_method)
          for(k in ((j-1)*size+1):(j*size))
          {
            if(M==5){
              if(n>p){
                #############################################################################   
                O_prcv <- prcvma(X=data[[k]],n=n,p=p,M=M,sigma=Sigma,PLS_type="SCAD_BIC")
                O_est <- O_prcv
                Loss_res <- Loss_res_func(Sigma,Omega,O_est,p)
                seq1 <- 1:length_loss
                res[k-(j-1)*size,seq1] <- Loss_res
                #############################################################################  
                O_imcd <- imcd(X=data[[k]],p=p,n=n,M=M,sigma=Sigma)
                O_est <- O_imcd
                Loss_res <- Loss_res_func(Sigma,Omega,O_est,p)
                seq2 <- (length_loss+1):(2*length_loss)
                res[k-(j-1)*size,seq2] <- Loss_res
                #############################################################################  
                O_PBA <- PBA(X=data[[k]],p=p,n=n,M=M,sigma=Sigma)
                O_est <- O_PBA
                Loss_res <- Loss_res_func(Sigma,Omega,O_est,p)
                seq3 <- (2*length_loss+1):(3*length_loss)
                res[k-(j-1)*size,seq3] <- Loss_res
                #############################################################################  
                O_rcv  <- rcvma(X=data[[k]],p=p,n=n,sigma=Sigma)
                O_est <- O_rcv
                Loss_res <- Loss_res_func(Sigma,Omega,O_est,p)
                seq4 <- (3*length_loss+1):(4*length_loss)
                res[k-(j-1)*size,seq4] <- Loss_res
                v1 <- v2 <- v3 <- NULL
                #############################################################################  
                tig  <- sugm(data[[k]],method="tiger")$icov
                for(z in 1:length(tig)){
                  v2 <- c(v2,KL(sigma=Sigma,estimator=tig[[z]]))
                }
                O_tig <- tig[[which.min(v2)]]
                O_est <- O_tig
                Loss_res <- Loss_res_func(Sigma,Omega,O_est,p)
                seq5 <- (4*length_loss+1):(5*length_loss)
                res[k-(j-1)*size,seq5] <- Loss_res
                #############################################################################  
                cli  <-   sugm(data[[k]],method="clime")$icov
                for(z in 1:length(cli)){
                  v1 <- c(v1,KL(sigma=Sigma,estimator=cli[[z]]))
                }
                O_cli <- cli[[which.min(v1)]]
                O_est <- O_cli
                Loss_res <- Loss_res_func(Sigma,Omega,O_est,p)
                seq6 <- (5*length_loss+1):(6*length_loss)
                res[k-(j-1)*size,seq6] <- Loss_res
                #############################################################################  
              }else{
                #############################################################################   
                O_prcv <- prcvma(X=data[[k]],n=n,p=p,M=M,sigma=Sigma,PLS_type="SCAD_BIC")
                O_est <- O_prcv
                Loss_res <- Loss_res_func(Sigma,Omega,O_est,p)
                seq1 <- 1:length_loss
                res[k-(j-1)*size,seq1] <- Loss_res
                #############################################################################  
                O_rcv  <- rcvma(X=data[[k]],p=p,n=n,sigma=Sigma)
                O_est <- O_rcv
                Loss_res <- Loss_res_func(Sigma,Omega,O_est,p)
                seq2 <- (length_loss+1):(2*length_loss)
                res[k-(j-1)*size,seq2] <- Loss_res
                v1 <- v2 <- v3 <- NULL
                #############################################################################  
                O_imcd <- imcd(X=data[[k]],p=p,n=n,M=M,sigma=Sigma)
                O_est <- O_imcd
                Loss_res <- Loss_res_func(Sigma,Omega,O_est,p)
                seq3 <- (2*length_loss+1):(3*length_loss)
                res[k-(j-1)*size,seq3] <- Loss_res
                #############################################################################  
                O_PBA <- PBA(X=data[[k]],p=p,n=n,M=M,sigma=Sigma)
                O_est <- O_PBA
                Loss_res <- Loss_res_func(Sigma,Omega,O_est,p)
                seq4 <- (3*length_loss+1):(4*length_loss)
                res[k-(j-1)*size,seq4] <- Loss_res
                #############################################################################  
                tig  <- sugm(data[[k]],method="tiger")$icov
                for(z in 1:length(tig)){
                  v2 <- c(v2,KL(sigma=Sigma,estimator=tig[[z]]))
                }
                O_tig <- tig[[which.min(v2)]]
                O_est <- O_tig
                Loss_res <- Loss_res_func(Sigma,Omega,O_est,p)
                seq5 <- (4*length_loss+1):(5*length_loss)
                res[k-(j-1)*size,seq5] <- Loss_res
                ############################################################################# 
              }
            }else{
              #############################################################################   
              O_prcv <- prcvma(X=data[[k]],n=n,p=p,M=M,sigma=Sigma,PLS_type="SCAD_BIC")
              O_est <- O_prcv
              Loss_res <- Loss_res_func(Sigma,Omega,O_est,p)
              seq1 <- 1:length_loss
              res[k-(j-1)*size,seq1] <- Loss_res
              #############################################################################  
              O_imcd <- imcd(X=data[[k]],p=p,n=n,M=M,sigma=Sigma)
              O_est <- O_imcd
              Loss_res <- Loss_res_func(Sigma,Omega,O_est,p)
              seq2 <- (length_loss+1):(2*length_loss)
              res[k-(j-1)*size,seq2] <- Loss_res
              #############################################################################  
              O_PBA <- PBA(X=data[[k]],p=p,n=n,M=M,sigma=Sigma)
              O_est <- O_PBA
              Loss_res <- Loss_res_func(Sigma,Omega,O_est,p)
              seq3 <- (2*length_loss+1):(3*length_loss)
              res[k-(j-1)*size,seq3] <- Loss_res
              #############################################################################
            }
          }
          return(res)
        }
      stopImplicitCluster
      stopCluster(cl)
      df<-apply(result,2,mean)
      dt<-apply(result,2,sd)
      rt<-rbind(df,dt)
      rs<-rbind(rs,rt)
      
      end_time <- proc.time()-start_time
      
      filename=paste("case-",case,"-p-",p,"-M-",M,'-time-',end_time[3],sep="")
      print(list(filename,rt))
    }
  }
}
file_name<-paste("n-",n,"-p-",p,"-M-",M,"-case-",1,"-iters-",iters,".csv")
write.csv(rs,file=file_name,quote=F,row.names = F)


