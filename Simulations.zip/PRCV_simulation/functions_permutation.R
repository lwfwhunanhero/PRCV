library(glmnet)
library(lassoshooting)
GetDiagSub <- function(ind,U){
  return(U[ind,ind])
}
DAGLassoseq <- function(Y, lambda.seq, maxitr=1000, tol=1e-4){
  require(lassoshooting)  
  p = ncol(Y)
  n = nrow(Y)
  S = (t(Y) %*% Y)/n
  
  T = diag(p)
  D = rep(1, p)
  
  itr_log = eps_log = NULL
  
  for (k in 2:p){
    
    nuk_old = nuk_new = c(rep(0, k-1), 1)
    r = 0
    km1_ = 1:(k-1)
    
    repeat {
      
      r = r + 1
      
      
      nuk_new[k] = D[k]
      
      
      output = lassoshooting(XtX= S[km1_,km1_,drop=FALSE], 
                             Xty=-S[km1_,k], maxit = 100, lambda=0.5*nuk_new[k]*lambda.seq[k])
      nuk_new[km1_] = output$coefficients

      maxdiff = max(abs(nuk_new - nuk_old))
      if (maxdiff < tol || r >= maxitr){
        T[k, km1_] = nuk_new[km1_]
        eps_log = c(eps_log, maxdiff)
        itr_log = c(itr_log, r)
        break
      } else {
        nuk_old = nuk_new
      }
      
    }
    
  }
  
 return(T)
}

## SpecialDet: function to calculate determinant of a square matrix, with special case checking
SpecialDet <- function(x){
  if(length(x)==0) return(1)
  if(length(x)==1) return(as.numeric(x))
  return(det(x))
}

SteinLoss <- function(trueSigma,Sigma,p,decomp=TRUE){
  if(decomp){
    SVD <- svd(trueSigma)
    SS <- t(SVD$u)%*%Sigma%*%SVD$v
    Cl <- chol(Sigma)
    term1 <- sum(diag(SS)/SVD$d)
    term2 <- -sum(log(SVD$d)) + 2*sum(log(diag(Cl)))
    L <- term1 - term2 - p
    return(L)
  }
  block <- solve(trueSigma,Sigma)
  ss <- svd(block)
  SVD <- svd(trueSigma)
  SS <- t(SVD$u)%*%Sigma%*%SVD$v
  term1 <- 
    L <- sum(diag(block)) - sum(log(ss$d)) - p
  return(L)
}


SquareLoss <- function(trueSigma,Sigma,Adj){
  DifMat2 <- (trueSigma - Sigma)^2
  return(sum((DifMat2[which(Adj != 0)])))
}

MAE <- function(trueSigma,Sigma,Adj){
  DifMat2 <- abs(trueSigma - Sigma)
  return(sum((DifMat2[which(Adj != 0)])))
}


Square.plain <- function(trueSigma,Sigma){
  DifMat2 <- (trueSigma - Sigma)^2
  return(sum((DifMat2)))
}

MAE.plain <- function(trueSigma,Sigma){
  DifMat2 <- abs(trueSigma - Sigma)
  return(sum((DifMat2)))
}

E.Prec <- function(alpha,U,Adj){
  m <- nrow(Adj)
  if((m!=ncol(Adj))||(m!=length(alpha))) stop("Dimension Incorrect!")
  pa.set <- apply(Adj,2,function(x){which(x!=0)})
  if(length(pa.set)>0){    
    pa.count <- unlist(lapply(pa.set,length))
    Gm <- matrix(NA,nrow=m,ncol=m)
    RU <- matrix(0,nrow=m,ncol=m)
    for(j in 1:m){
      pa.self <- c(j,pa.set[[j]])
      U.pa.self <- GetDiagSub(pa.self,U)
      tmp.U2 <- tmp.U1 <- matrix(0,m,m)
      tmp.U1[pa.self,pa.self] <- (alpha[j]-pa.count[j]-2)*solve(U.pa.self)
      
      if(pa.count[j]>0){
        tmp.U2[pa.set[[j]],pa.set[[j]]] <- (alpha[j]-pa.count[j]-3)*solve(GetDiagSub(pa.set[[j]],U))
        
      } 
      RU <- RU + tmp.U1 - tmp.U2
    }
    for(j in 1:m){
      if(pa.count[j]>0){
        Gm[pa.set[[j]],j] <- RU[pa.set[[j]],j]
        Gm[j,pa.set[[j]]] <- Gm[pa.set[[j]],j]
      }
    }
    diag(Gm) <- diag(RU)
  }else{
    Gm <- matrix(0,nrow=m,ncol=m)
    diag(Gm) <- (alpha-2)/diag(U)
    return(Gm)
  }
  Lambda <- L <- matrix(0,m,m)
  diag(L) <- 1
  Lambda[1,1] <- Gm[1,1]
  if(pa.count[1]>0){
    for(i in pa.set[[1]]){
      L[i,1] <- Gm[i,1]/Lambda[1,1]
    }
  }
  for(j in 2:m){
    Lambda[j,j] <- Gm[j,j] - sum((diag(Lambda)*L[j,]^2)[1:(j-1)])
    if(pa.count[j]>0){
      for(i in pa.set[[j]]){
        L[i,j] <- (Gm[i,j] - sum((diag(Lambda)*L[i,]*L[j,])[1:(j-1)]))/Lambda[j,j]
      }
    }
  }
  return(L%*%(Lambda)%*%t(L))
}




E.Sigma <- function(alpha,U,Adj){
  m <- nrow(Adj)
  if((m!=ncol(Adj))||(m!=length(alpha))) stop("Dimension Incorrect!")
  pa.set <- apply(Adj,2,function(x){which(x!=0)})
  Sigma <- matrix(0,m,m)
  if(length(pa.set)==0){
    diag(Sigma) <- diag(U)/(alpha-4)
    return(Sigma)
  }
  pa.count <- unlist(lapply(pa.set,length))
  Sigma[m,m] <- U[m,m]/(alpha[m]-4)
  for(i in seq((m-1),1,by=-1)){
    if(pa.count[i]==0){
      Sigma[i,i] <- U[i,i]/(alpha[i]-4)
      Sigma[i,((i+1):m)] <- Sigma[((i+1):m),i] <- 0
    }else{
      block <- solve(matrix(GetDiagSub(pa.set[[i]],U),ncol=pa.count[i]),matrix(U[pa.set[[i]],i],ncol=1))
      Sigma[pa.set[[i]],i] <- matrix(GetDiagSub(pa.set[[i]],Sigma),ncol=pa.count[i]) %*% block
      cond.U.pa <- as.numeric(U[i,i]-matrix(U[i,pa.set[[i]]],nrow=1)%*%block)
      tmp.inner <- matrix(Sigma[pa.set[[i]],i],ncol=1)%*%t(block) + cond.U.pa*t(solve(matrix(GetDiagSub(pa.set[[i]],U),ncol=pa.count[i]),matrix(GetDiagSub(pa.set[[i]],Sigma),ncol=pa.count[i])))/(alpha[i]-pa.count[i]-4)
      Sigma[i,i] <- cond.U.pa/(alpha[i]-pa.count[i]-4) + sum(diag(tmp.inner))
      if(pa.count[i]<(m-i)){
        non.pa <- setdiff(seq((i+1),m),pa.set[[i]])
        Sigma[non.pa,i] <- matrix(Sigma[non.pa,pa.set[[i]]],ncol=pa.count[i]) %*% solve(matrix(GetDiagSub(pa.set[[i]],Sigma),ncol=pa.count[i]),matrix(Sigma[pa.set[[i]],i],ncol=1))
      }
      Sigma[i,((i+1):m)] <- Sigma[((i+1):m),i]
    }
  }
  return(Sigma)
}

DAG.MLE <- function(S,Adj){
  m <- nrow(S)
  Psi <- matrix(0,m,m)
  Psi[m,m] <- S[m,m]
  pa.set <- apply(Adj,2,function(x){which(x!=0)})
  if(length(pa.set)==0){
    diag(Psi) <- diag(S)
    return(Psi)
  }
  pa.count <- unlist(lapply(pa.set,length))
  for(i in seq(m-1,1)){
    if(pa.count[i]==0){
      Psi[i,i] <- S[i,i]
    }
    if(pa.count[i]>0){
      Spa <- GetDiagSub(pa.set[[i]],S)
      Spa.invert <- solve(Spa)
      Psipa <- matrix(GetDiagSub(pa.set[[i]],Psi),ncol=pa.count[i])
      beta <- matrix(Spa.invert%*%S[pa.set[[i]],i],ncol=1)
      Psi[pa.set[[i]],i] <- Psipa%*%beta
      lambda <- S[i,i] - as.numeric(matrix(S[i,pa.set[[i]]],nrow=1)%*%beta)
      Psi[i,i] <- lambda + as.numeric(t(beta)%*%Psipa%*%beta)
      if((m-i)-pa.count[i]>0){
        non.pa.set <- setdiff((i+1):m,pa.set[[i]])
        Psi[non.pa.set,i] <- Psi[non.pa.set,pa.set[[i]]]%*%solve(Psipa)%*%Psi[pa.set[[i]],i]
      }
    }
    Psi[i,] <- Psi[,i]
    if(any(Psi[i,]>1e10)) break
  }
  return(Psi)
}


DAG.MAP <- function(S,Adj,U,alpha.c,alpha.b,n){
  m <- nrow(S)
  Psi <- matrix(0,m,m)
  S <- n*S + U
  alpha <- rep(alpha.b,m)
  Psi[m,m] <- S[m,m]/(alpha[m]+n)
  pa.set <- apply(Adj,2,function(x){which(x!=0)})
  if(length(pa.set)==0){
    diag(Psi) <- diag(S)/(alpha+n)
    return(Psi)
  }
  pa.count <- unlist(lapply(pa.set,length))
  if(length(pa.set)>0){
    alpha <- alpha + alpha.c*pa.count
  }
  
  for(i in seq(m-1,1)){
    if(pa.count[i]==0){
      Psi[i,i] <- S[i,i]/(alpha[i]+n)
    }
    if(pa.count[i]>0){
      Spa <- GetDiagSub(pa.set[[i]],S)
      Spa.invert <- solve(Spa)
      Psipa <- matrix(GetDiagSub(pa.set[[i]],Psi),ncol=pa.count[i])
      beta <- matrix(Spa.invert%*%S[pa.set[[i]],i],ncol=1)
      Psi[pa.set[[i]],i] <- Psipa%*%beta
      lambda <- (S[i,i] - as.numeric(matrix(S[i,pa.set[[i]]],nrow=1)%*%beta))/(alpha[i]+n)
      Psi[i,i] <- lambda + as.numeric(t(beta)%*%Psipa%*%beta)
      if((m-i)-pa.count[i]>0){
        non.pa.set <- setdiff((i+1):m,pa.set[[i]])
        Psi[non.pa.set,i] <- Psi[non.pa.set,pa.set[[i]]]%*%solve(Psipa)%*%Psi[pa.set[[i]],i]
      }
    }
    Psi[i,] <- Psi[,i]
    if(any(Psi[i,]>1e10)) break
  }
  return(Psi)
}

permuteMatrix <- function(p) {
  P = diag(p)
  P = P[, sample(p)]
  return(P)
}

