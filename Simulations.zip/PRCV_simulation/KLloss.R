
KL <- function(sigma,estimator){
  p <- ncol(sigma)
  loss <- ( sum(diag(sigma%*%estimator)) - log(det(sigma%*%estimator)) - p )/p
  return(loss)
}

F_norm <- function(omega,estimator) {
  p <- ncol(omega)
  x <- abs(omega-estimator)
  loss <- sqrt(sum(x^2))/p
  return(loss)
}

L1_norm <- function(omega,estimator) {
  p <- ncol(omega)
  x <- abs(omega-estimator)
  loss <- sum(abs(x))/p
  return(loss)
}
library(pROC)
AUC_norm <- function(omega,estimator) {
  omega[which(omega!=0)]=1
  estimator[which(estimator!=0)]=1
  true_labels <- as.vector(omega)
  predicted_probs <- as.vector(estimator)
  roc_obj <- roc(true_labels, predicted_probs)
  auc_value <- auc(roc_obj)
  return(auc_value)
}

Entrymax_norm <- function(omega,estimator){
  A <- omega-estimator
  norm_inf <- max(abs(A))
  return(norm_inf)
}


SteinLoss <- function(omega,estimator,decomp=TRUE){
  p <- ncol(estimator)
  if(decomp){
    SVD <- svd(omega)
    SS <- t(SVD$u)%*%estimator%*%SVD$v
    Cl <- chol(estimator)
    term1 <- sum(diag(SS)/SVD$d)
    term2 <- -sum(log(SVD$d)) + 2*sum(log(diag(Cl)))
    L <- term1 - term2 - p
  }
  block <- solve(omega,estimator)
  ss <- svd(block)
  SVD <- svd(omega)
  SS <- t(SVD$u)%*%estimator%*%SVD$v
  L <- sum(diag(block)) - sum(log(ss$d)) - p
  return(L)
}


SquareLoss <- function(omega,estimator,p){
  true.Adj <- omega
  true.Adj[upper.tri(true.Adj)] <- 0
  diag(true.Adj) <- 0
  true.Adj[which(true.Adj!=0)] <- 1
  Adj <- true.Adj
  DifMat2 <- (omega - estimator)^2
  res <- sum((DifMat2[which(Adj != 0)]))/p
  return(res)
}

MAE <- function(omega,estimator,p){
  true.Adj <- omega
  true.Adj[upper.tri(true.Adj)] <- 0
  diag(true.Adj) <- 0
  true.Adj[which(true.Adj!=0)] <- 1
  Adj <- true.Adj
  DifMat2 <- abs(omega - estimator)
  res <- sum((DifMat2[which(Adj != 0)]))/p
  return(res)
}





