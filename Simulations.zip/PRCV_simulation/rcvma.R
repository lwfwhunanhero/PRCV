rcvma<-function(X,p,n,sigma)
{
      library(SIS)
      library(MASS)
      Lhat1<- matrix(0,nrow=p,ncol=p) + diag(p)
      Lhat2<- matrix(0,nrow=p,ncol=p) + diag(p)
      Dhat1<-Dhat2<-matrix(0,nrow=p,ncol=p)
      index<-sample(1:n,n/2,replace=FALSE)
      X1 <- X[index,]; X2 <- X[-index,]
      list1<-list2<-list3<-list4<-list()
      for(j in 2:p){
          list1[[j-1]]<-X1[,1:j] 
          list2[[j-1]]<-X2[,1:j]
      }
      Dhat1[1,1]<-var(X2[,1])
      Dhat2[1,1]<-var(X1[,1])
      
######################################################

      FS1<-SIS(data.matrix(list1[[1]][,-ncol(list1[[1]])]),as.vector(list1[[1]][,ncol(list1[[1]])]), 
               family='gaussian',iter=FALSE)# use sis to select features
      list3[[1]]<-FS1$sis.ix0 #take selected features'locations
      v<-length(list3[[1]]) # the number of selected features
      if (v==0){
          Lhat1[2,]<-Lhat1[2,]
          Dhat1[2,2]<-var(X2[,2])
      }else{
            data<-data.frame(y=X2[,2],X2[,list3[[1]]])
            estima<-lm(y~.,data=data)
            Lhat1[2,list3[[1]]]<- -1*coef(estima)[-1]
            Dhat1[2,2]<-sum(residuals(estima)^2)/estima$df.residual
      }
######################################################
      for(i in 2:(p-1)){
          FS<-SIS(data.matrix(list1[[i]][,-ncol(list1[[i]])]),as.vector(list1[[i]][,ncol(list1[[i]])]),
                  penalty='SCAD',family='gaussian',tune='bic',seed=111)
          list3[[i]]<-FS$ix
          v<-length(list3[[i]])
          if(v==0){
            Lhat1[i+1,]<-Lhat1[i+1,]
            Dhat1[i+1,i+1]<-var(X2[,i+1])
          }else if(v==1){
            ##### OLS
            data<-data.frame(y=X2[,i+1],X2[,list3[[i]]])
            estima<-lm(y~.,data=data)
            Lhat1[i+1,list3[[i]]]<- -1*coef(estima)[-1]
            Dhat1[i+1,i+1]<-sum(residuals(estima)^2)/estima$df.residual
          }else{
            ##### SCAD+BIC
            fit <- asnet(X2[,list3[[i]]], X2[,i+1], family = 'gaussian', tune = 'bic')
            Lhat1[i+1,list3[[i]]] <- -1*coef(fit)
            residuals <- X2[,i+1]-X2[,list3[[i]]]%*%coef(fit)
            Dhat1[i+1,i+1]<-mean(residuals^2)
          }
      }

########################################################################
      FS2<-SIS(data.matrix(list2[[1]][,-ncol(list2[[1]])]),as.vector(list2[[1]][,ncol(list2[[1]])]), 
               family='gaussian',iter=FALSE)
      list4[[1]]<-FS2$sis.ix0
      v<-length(list4[[1]])
      if(v==0){
         Lhat2[1+1,]<-Lhat2[1+1,]
         Dhat2[2,2]<-var(X1[,1+1])
      }else{
            data<-data.frame(y=X1[,1+1],X1[,list4[[1]]])
            estima<-lm(y~.,data=data)
            Lhat2[1+1,list4[[1]]]<- -1*coef(estima)[-1]
            Dhat2[2,2]<-sum(residuals(estima)^2)/estima$df.residual
      }
######################################################
      for(i in 2:(p-1)){
          FS<-SIS(data.matrix(list2[[i]][,-ncol(list2[[i]])]),as.vector(list2[[i]][,ncol(list2[[i]])]),
                  penalty='SCAD',family='gaussian',tune='bic',seed=111)
          list4[[i]]<-FS$ix
          v<-length(list4[[i]])
          if (v==0){
            Lhat2[i+1,]<-Lhat2[i+1,]
            Dhat2[i+1,i+1]<-var(X1[,i+1])
          }else if(v==1){
            ##### OLS
            data<-data.frame(y=X1[,i+1],X1[,list4[[i]]])
            estima<-lm(y~.,data=data)
            Lhat2[i+1,list4[[i]] ]<- -1*coef(estima)[-1]
            Dhat2[i+1,i+1]<-sum(residuals(estima)^2)/estima$df.residual
          }else{
            ##### SCAD+BIC
            fit <- asnet(X1[,list4[[i]]], X1[,i+1], family = 'gaussian', tune = 'bic')
            Lhat2[i+1,list4[[i]]] <- -1*coef(fit)
            residuals <- X1[,i+1]-X1[,list4[[i]]]%*%coef(fit)
            Dhat2[i+1,i+1]<-mean(residuals^2)
          }
      }
      Dhat<-(Dhat1+Dhat2)/2
      Lhat<-(Lhat1+Lhat2)/2
########################################################################
      O_res <- t(Lhat)%*%solve(Dhat)%*%Lhat
      return(O_res)
}