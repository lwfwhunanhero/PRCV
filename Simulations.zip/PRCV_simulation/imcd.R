
imcd<-function(X,p,n,M,sigma){
  Lp<-matrix(0,nrow=p,ncol=p)   
  D<-matrix(0,nrow=p,ncol=p)
  for(i in 1:M){
    Dhat1<-matrix(0,nrow=p,ncol=p)
    Lhat1<- matrix(0,nrow=p,ncol=p) + diag(p)

    ##########  generate permutation matrix  #############
    
    Pertation<-matrix(0,nrow=p,ncol=p)
    Per<-sample(1:p,p,replace=FALSE)
    for(i in 1:p){
      Pertation[Per[i],i]<-1
    }
    
    #### after permuting
    
    list1 <- list()
    XP <- X%*%Pertation
    list1<-list2<-list3<-list4<-list()
    for(j in 2:p){
      list1[[j-1]]<-XP[,1:j] 
    }
    Dhat1[1,1]<-var(XP[,1])
    
    ######################################################
    ##### OLS
    data<-data.frame(y=as.vector(list1[[1]][,ncol(list1[[1]])]),data.matrix(list1[[1]][,-ncol(list1[[1]])]))
    estima<-lm(y~.,data=data)
    Lhat1[2,1]<- -1*coef(estima)[-1]
    Dhat1[2,2]<-sum(residuals(estima)^2)/estima$df.residual
    
    
    for(i in 2:(p-1)){
      cvob <- cv.glmnet(data.matrix(list1[[i]][,-ncol(list1[[i]])]),as.vector(list1[[i]][,ncol(list1[[i]])]), 
                        alpha=1)
      fit <- glmnet(data.matrix(list1[[i]][,-ncol(list1[[i]])]),as.vector(list1[[i]][,ncol(list1[[i]])]),
                    alpha=1, lambda=cvob$lambda.min)
      Lhat1[i+1,1:i] <- -1*coef(fit)[-1]
      residuals <- as.vector(list1[[i]][,ncol(list1[[i]])])-
        data.matrix(list1[[i]][,-ncol(list1[[i]])])%*%coef(fit)[-1]
      Dhat1[i+1,i+1]<-mean(residuals^2)
    }
    
    ########################################################################
    Dhat1<-(Pertation)%*%Dhat1%*%t(Pertation)
    Lhat1<-(Pertation)%*%Lhat1%*%t(Pertation)
    D<-D+Dhat1  #####  M*P
    Lp<-Lp+Lhat1
  }
  
  ########################################################################
  Ttilde <- Lp/M
  Dtilde <- D/M
  delta <- seq(0,1,length.out=100)
  BIC_seq <- sapply(1:length(delta),function(x){
    thresholded_mat <- Ttilde
    thresholded_mat[abs(thresholded_mat) < delta[x]] <- 0
    Tdelta <- thresholded_mat
    O_delta <- t(Tdelta)%*%solve(Dtilde)%*%Tdelta
    BIC_delta <- -log(det(O_delta))+sum(diag(O_delta%*%cov(X)))+log(n)*(sum(O_delta!=0)+p)/(2*n)
    return(BIC_delta)
  })
  delta_opt <- delta[which.min(BIC_seq)]
  thresholded_mat <- Ttilde
  thresholded_mat[abs(thresholded_mat) < delta_opt] <- 0
  T_opt <- thresholded_mat
  O_opt <- t(T_opt)%*%solve(Dtilde)%*%T_opt
  return(O_opt)
}