##########################   prcv  #######################
library(msaenet) #SCAD + AIC/BIC
prcvma<-function(X,n,p,M,sigma,PLS_type="SCAD_BIC")
{
  library(SIS)
  Lp<-matrix(0,nrow=p,ncol=p)
  D<-matrix(0,nrow=p,ncol=p)
     for(i in 1:M)
     {
         Dhat1<-Dhat2<-matrix(0,nrow=p,ncol=p)
         Lhat1<- matrix(0,nrow=p,ncol=p) + diag(p)
         Lhat2<- matrix(0,nrow=p,ncol=p) + diag(p)
     
     ##########  generate permutation matrix  #############
     
         Pertation<-matrix(0,nrow=p,ncol=p)
         Per<-sample(1:p,p,replace=FALSE)
         for(i in 1:p){
             Pertation[Per[i],i]<-1
         }
     
     #### after permuting
     
         index<-sample(1:n,n/2,replace=FALSE)
         X2<-X[index,]%*%Pertation; X1<-X[-index,]%*%Pertation
         list1<-list2<-list3<-list4<-list()
         for(j in 2:p){
         list1[[j-1]]<-X1[,1:j] 
         list2[[j-1]]<-X2[,1:j]
         }
         Dhat1[1,1]<-var(X2[,1])
         Dhat2[1,1]<-var(X1[,1])
     
  ######################################################
  
     FS1<-SIS(data.matrix(list1[[1]][,-ncol(list1[[1]])]),as.vector(list1[[1]][,ncol(list1[[1]])]), 
           family='gaussian',iter=FALSE)# use sis to select features
     list3[[1]]<-FS1$sis.ix0 #take selected features'locations
     v<-length(list3[[1]]) # the number of selected features
     if(v==0){
           Lhat1[2,]<-Lhat1[2,]
           Dhat1[2,2]<-var(X2[,2])
     }else{
           ##### OLS
           data<-data.frame(y=X2[,2],X2[,list3[[1]]])
           estima<-lm(y~.,data=data)
           Lhat1[2,list3[[1]]]<- -1*coef(estima)[-1]
           Dhat1[2,2]<-sum(residuals(estima)^2)/estima$df.residual
      }
  
     for(i in 2:(p-1)){
        FS<-SIS(data.matrix(list1[[i]][,-ncol(list1[[i]])]),as.vector(list1[[i]][,ncol(list1[[i]])]),
            penalty='SCAD' ,family='gaussian',tune='bic',seed=111)
        list3[[i]]<-FS$ix
        v<-length(list3[[i]])
        if(v==0){
          Lhat1[i+1,]<-Lhat1[i+1,]
          Dhat1[i+1,i+1]<-var(X2[,i+1])
        }else if(v==1){
          ##### OLS
          data<-data.frame(y=X2[,i+1],X2[,list3[[i]]])
          estima<-lm(y~.,data=data)
          Lhat1[i+1,list3[[i]]]<- -1*coef(estima)[-1]
          Dhat1[i+1,i+1]<-sum(residuals(estima)^2)/estima$df.residual
        }else{
          if(PLS_type=="lasso_AIC"){
            ##### lasso+AIC
            fit <- glmnet(X2[,list3[[i]]], X2[,i+1], family = 'gaussian')
            k <- fit$df
            AIC <- stats::deviance(fit)+2*k
            i_min = which.min(AIC)
            lambda_select = fit$lambda[i_min]
            fit_AIC <- glmnet(X2[,list3[[i]]], X2[,i+1], family = 'gaussian',lambda = lambda_select)
            Lhat1[i+1,list3[[i]]] <- -1*coef(fit_AIC)[-1]
            residuals <- X2[,i+1]-X2[,list3[[i]]]%*%coef(fit_AIC)[-1]
            Dhat1[i+1,i+1]<-mean(residuals^2)
          }else if(PLS_type=="lasso_BIC"){
            ##### lasso+BIC
            fit <- glmnet(X2[,list3[[i]]], X2[,i+1], family = 'gaussian')
            k <- fit$df
            BIC <- stats::deviance(fit)+log(n)*k
            i_min = which.min(BIC)
            lambda_select = fit$lambda[i_min]
            fit_BIC <- glmnet(X2[,list3[[i]]], X2[,i+1], family = 'gaussian',lambda = lambda_select)
            Lhat1[i+1,list3[[i]]] <- -1*coef(fit_BIC)[-1]
            residuals <- X2[,i+1]-X2[,list3[[i]]]%*%coef(fit_BIC)[-1]
            Dhat1[i+1,i+1]<-mean(residuals^2)
          }else if(PLS_type=="SCAD_AIC"){
            ##### SCAD+AIC
            fit <- asnet(X2[,list3[[i]]], X2[,i+1], family = 'gaussian', tune = 'aic')
            Lhat1[i+1,list3[[i]]] <- -1*coef(fit)
            residuals <- X2[,i+1]-X2[,list3[[i]]]%*%coef(fit)
            Dhat1[i+1,i+1]<-mean(residuals^2)
          }else if(PLS_type=="SCAD_BIC"){
            ##### SCAD+BIC
            fit <- asnet(X2[,list3[[i]]], X2[,i+1], family = 'gaussian', tune = 'bic')
            Lhat1[i+1,list3[[i]]] <- -1*coef(fit)
            residuals <- X2[,i+1]-X2[,list3[[i]]]%*%coef(fit)
            Dhat1[i+1,i+1]<-mean(residuals^2)
          }
        }
          
          
     }
  ########################################################################
     
     FS2<-SIS(data.matrix(list2[[1]][,-ncol(list2[[1]])]),as.vector(list2[[1]][,ncol(list2[[1]])]), 
           family='gaussian',iter=FALSE)
     list4[[1]]<-FS2$sis.ix0
     v<-length(list4[[1]])
     if(v==0){
           Lhat2[1+1,]<-Lhat2[1+1,]
           Dhat2[1+1,2]<-var(X1[,1+1])
     }else{
           ##### OLS
           data<-data.frame(y=X1[,1+1],X1[,list4[[1]]])
           estima<-lm(y~.,data=data)
           Lhat2[1+1,list4[[1]]]<- -1*coef(estima)[-1]
           Dhat2[1+1,2]<-sum(residuals(estima)^2)/estima$df.residual
      }
  
  
     for(i in 2:(p-1)){
         FS<-SIS(data.matrix(list2[[i]][,-ncol(list2[[i]])]),as.vector(list2[[i]][,ncol(list2[[i]])]),
            penalty='SCAD' ,family='gaussian',tune='bic',seed=111)
         list4[[i]]<-FS$ix
         v<-length(list4[[i]])
         if (v==0){
               Lhat2[i+1,]<-Lhat2[i+1,]
               Dhat2[i+1,i+1]<-var(X1[,i+1])
         }else if(v==1){
               ##### OLS
               data<-data.frame(y=X1[,i+1],X1[,list4[[i]]])
               estima<-lm(y~.,data=data)
               Lhat2[i+1,list4[[i]] ]<- -1*coef(estima)[-1]
               Dhat2[i+1,i+1]<-sum(residuals(estima)^2)/estima$df.residual
         }else{
           if(PLS_type=="lasso_AIC"){
             ##### lasso+AIC
             fit <- glmnet(X1[,list4[[i]]], X1[,i+1], family = 'gaussian')
             k <- fit$df
             AIC <- stats::deviance(fit)+2*k
             i_min = which.min(AIC)
             lambda_select = fit$lambda[i_min]
             fit_AIC <- glmnet(X1[,list4[[i]]], X1[,i+1], family = 'gaussian',lambda = lambda_select)
             Lhat2[i+1,list4[[i]]] <- -1*coef(fit_AIC)[-1]
             residuals <- X1[,i+1]-X1[,list4[[i]]]%*%coef(fit_AIC)[-1]
             Dhat2[i+1,i+1]<-mean(residuals^2)
           }else if(PLS_type=="lasso_BIC"){
             ##### lasso+BIC
             fit <- glmnet(X1[,list4[[i]]], X1[,i+1], family = 'gaussian')
             k <- fit$df
             BIC <- stats::deviance(fit)+log(n)*k
             i_min = which.min(BIC)
             lambda_select = fit$lambda[i_min]
             fit_BIC <- glmnet(X1[,list4[[i]]], X1[,i+1], family = 'gaussian',lambda = lambda_select)
             Lhat2[i+1,list4[[i]]] <- -1*coef(fit_BIC)[-1]
             residuals <- X1[,i+1]-X1[,list4[[i]]]%*%coef(fit_BIC)[-1]
             Dhat2[i+1,i+1]<-mean(residuals^2)
           }else if(PLS_type=="SCAD_AIC"){
             ##### SCAD+AIC
             fit <- asnet(X1[,list4[[i]]], X1[,i+1], family = 'gaussian', tune = 'aic')
             Lhat2[i+1,list4[[i]]] <- -1*coef(fit)
             residuals <- X1[,i+1]-X1[,list4[[i]]]%*%coef(fit)
             Dhat2[i+1,i+1]<-mean(residuals^2)
           }else if(PLS_type=="SCAD_BIC"){
             ##### SCAD+BIC
             fit <- asnet(X1[,list4[[i]]], X1[,i+1], family = 'gaussian', tune = 'bic')
             Lhat2[i+1,list4[[i]]] <- -1*coef(fit)
             residuals <- X1[,i+1]-X1[,list4[[i]]]%*%coef(fit)
             Dhat2[i+1,i+1]<-mean(residuals^2)
           }
         }
         
     }
########################################################################
         Dhat1<-(Pertation)%*%Dhat1%*%t(Pertation)
         Dhat2<-(Pertation)%*%Dhat2%*%t(Pertation)
         Lhat1<-(Pertation)%*%Lhat1%*%t(Pertation)
         Lhat2<-(Pertation)%*%Lhat2%*%t(Pertation)
         Dhat<-(Dhat1+Dhat2)/2
         Lhat<-(Lhat1+Lhat2)/2
         D<-D+Dhat  #####  M*P
         Lp<-Lp+Lhat
     }
  Lres <- Lp/M
  Dres <- D/M
  ##### hard_thresholding
  lambda_hard <- sqrt(log(p)/(M*n))    
  Lres[abs(Lres) < lambda_hard] <- 0
  Dres[abs(Dres) < lambda_hard] <- 0
  
  O_res <- t(Lres)%*%solve(Dres)%*%Lres
  return(O_res)
}