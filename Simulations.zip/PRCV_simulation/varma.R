varma<-function(X,p,n,sigma)
{
      library(SIS)
      library(MASS)
      Lhat1<- matrix(0,nrow=p,ncol=p) + diag(p)
      Dhat1<-matrix(0,nrow=p,ncol=p)
      list1<-list3<-list()
      for(j in 2:p){
          list1[[j-1]]<-X[,1:j] 
      }
      Dhat1[1,1]<-var(X[,1])
######################################################
      FS1<-SIS(data.matrix(list1[[1]][,-ncol(list1[[1]])]),
               as.vector(list1[[1]][,ncol(list1[[1]])]), 
               family='gaussian',iter=FALSE)# use sis to select features
      list3[[1]]<-FS1$sis.ix0 #take selected features'locations
      v<-length(list3[[1]]) # the number of selected features
      if (v==0){
          Lhat1[2,]<-Lhat1[2,]
          Dhat1[2,2]<-var(X[,2])
      }else{
            data<-data.frame(y=X[,2],X[,list3[[1]]])
            estima<-lm(y~.,data=data)
            Lhat1[2,list3[[1]]]<- -1*coef(estima)[-1]
            Dhat1[2,2]<-sum(residuals(estima)^2)/estima$df.residual
       }


      for(i in 2:(p-1)){
          FS<-SIS(data.matrix(list1[[i]][,-ncol(list1[[i]])]),
                  as.vector(list1[[i]][,ncol(list1[[i]])]),
                  penalty='SCAD',family='gaussian',tune='bic',seed=111)
          list3[[i]]<-FS$ix
          v<-length(list3[[i]])
          if (v==0){
                Lhat1[i+1,]<-Lhat1[i+1,]
                Dhat1[i+1,i+1]<-var(X[,i+1])
          }else{
                data<-data.frame(y=X[,i+1],X[,list3[[i]]])
                estima<-lm(y~.,data=data)
                Lhat1[i+1,list3[[i]]]<- -1*coef(estima)[-1]
                Dhat1[i+1,i+1]<-sum(residuals(estima)^2)/estima$df.residual
           }
      }
      O_res <- t(Lhat1)%*%solve(Dhat1)%*%Lhat1
      return(O_res)
}